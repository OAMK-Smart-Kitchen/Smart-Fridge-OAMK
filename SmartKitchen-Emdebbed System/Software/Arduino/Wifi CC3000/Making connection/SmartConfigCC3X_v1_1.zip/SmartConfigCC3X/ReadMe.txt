
===========================
CC3000 SmartConfig Android App
SP 1.1
===========================

===============================================================================
Changed from previous versions:
===============================================================================
From 1.0:

1) Fix SSID identification bug in Android 4.2 (Jelly Bean)
2) Added algorithm enhancements, improves stability and robustness.


Please visit our wiki page at:
http://processors.wiki.ti.com/index.php/Smart_Config_Application_development_information_-_Android


