/** Automatically generated file. DO NOT MODIFY */
package com.ti.cc3x.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}